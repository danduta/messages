#include "client.h"
#include "server.h"
#include "message.h"

using namespace std;

int main(int argc, char** args)
{
    if (argc < 4 || argc > 4) {
        cout << "Usage:\t./subscriber <ID_Client> <IP_Server> <Port_Server>" << endl;
        return -1;
    }

    int port;
    int serv_fd;
    int ret;
    char* id = args[1];
    sockaddr_in serv_addr;
    tcp_message m;
    message rcv_msg;

    serv_fd = socket(PF_INET, SOCK_STREAM, 0);
	DIE(serv_fd < 0, "socket");

    port = atoi(args[3]);
    DIE (port < 0, "atoi");

    memset(&serv_addr, 0, sizeof(struct sockaddr_in));
	serv_addr.sin_family = PF_INET;
	serv_addr.sin_port = htons(port);
	ret = inet_aton(args[2], &serv_addr.sin_addr);
	DIE(ret == 0, "inet_aton");

	ret = connect(serv_fd, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
	DIE(ret < 0, "connect");

    m.type = TCP_CONN;
    strncpy(m.cli_id, id, CLIENT_ID_LEN);

    do {
        ret = send(serv_fd, &m, TCP_MSG_SIZE, 0);
    } while (ret != TCP_MSG_SIZE);

    fd_set fds;
    fd_set tmp;

    FD_ZERO(&fds);
    FD_ZERO(&tmp);
    FD_SET(serv_fd, &fds);
    FD_SET(STDIN_FILENO, &fds);

    int fdmax = serv_fd;

    // testing the operator overload
    inet_aton("1.2.3.4", &rcv_msg.addr.sin_addr);
    rcv_msg.addr.sin_port = htons(12345);
    rcv_msg.udp_msg.type = STRING;
    strcpy(rcv_msg.udp_msg.topic, "topic_test");
    strcpy(rcv_msg.udp_msg.payload, "test de string lalalalalla");
    cout << rcv_msg << endl;

    while (1) {
        tmp = fds;

        ret = select(fdmax + 1, &tmp, NULL, NULL, NULL);
		DIE(ret < 0, "select");

        for (int i = 0; i <= fdmax; i++) {
            if (FD_ISSET(i, &tmp)) {
                if (i == STDIN_FILENO) {
                    char buffer[2 * TOPIC_LEN];
                    fgets(buffer, 2 * TOPIC_LEN, stdin);
                    char* newline = strchr(buffer, '\n');

                    if (newline) {
                        *newline = '\0';
                    }

                    m.sf = false;

                    if (strncmp(buffer, "exit", 4) == 0) {
                        m.type = TCP_EXIT;
                    } else if (strncmp(buffer, "subscribe", 9) == 0) {
                        DEBUG("Subscribing...");

                        if (buffer[strlen(buffer) - 1] == '1') {
                            m.sf = true;
                        }

                        strcpy(m.payload, strchr(buffer, ' ') + 1);

                        char* space = strchr(m.payload, ' ');

                        if (space) {
                            *space = '\0';
                        }

                        m.type = TCP_SUB;
                    } else if (strncmp(buffer, "unsubscribe", 11) == 0) {
                        DEBUG("Unsubscribing...");
                        strcpy(m.payload, strchr(buffer, ' ') + 1);
                        m.type = TCP_UNSUB;
                    } else {
                        continue;
                    }

                    strncpy(m.cli_id, id, CLIENT_ID_LEN);

                    do {
                        ret = send(serv_fd, &m, TCP_MSG_SIZE, 0);
                    } while (ret != TCP_MSG_SIZE);
                    // DIE(ret != TCP_MSG_SIZE, "send");

                    DEBUG("Sent message: " + string(m.payload));

                    if (m.type == TCP_EXIT) {
                        DEBUG("Closing client...");
                        close(serv_fd);
                        return 0;
                    }
                } else if (i == serv_fd) {
                    ssize_t bytes = recv(serv_fd, &rcv_msg, MSG_SIZE, 0);
                    
                    if (bytes < MIN_FWD_SIZE) {
                        continue;
                    }

                    cout << rcv_msg << endl;
                }
            }
        }
    }

    return 0;
}